import { useState, useEffect } from 'react';

// Emoji pairs for the cards
const emojis = ['🍎', '🍌', '🍒', '🍓', '🍊', '🍋', '🍉', '🍇', '🍐', '🥝', '🍑', '🥭'];

type Card = {
  id: number;
  emoji: string;
  flipped: boolean;
  matched: boolean;
};

export default function App() {
  const [cards, setCards] = useState<Card[]>([]);
  const [moves, setMoves] = useState(0);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [gameWon, setGameWon] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Initialize the game
  useEffect(() => {
    startNewGame();
  }, []);

  // Check if all cards are matched
  useEffect(() => {
    if (cards.length > 0 && cards.every(card => card.matched)) {
      setGameWon(true);
    }
  }, [cards]);

  // Handle card flipping logic
  useEffect(() => {
    if (flippedIndices.length === 2 && !isProcessing) {
      setIsProcessing(true);
      setMoves(prev => prev + 1);
      
      const [firstIdx, secondIdx] = flippedIndices;
      const firstCard = cards[firstIdx];
      const secondCard = cards[secondIdx];

      if (firstCard.emoji === secondCard.emoji) {
        // Match found!
        setCards(prev => 
          prev.map((card, idx) => 
            idx === firstIdx || idx === secondIdx ? { ...card, matched: true } : card
          )
        );
      }

      // Flip cards back if no match after a delay
      const timer = setTimeout(() => {
        if (firstCard.emoji !== secondCard.emoji) {
          setCards(prev => 
            prev.map((card, idx) => 
              idx === firstIdx || idx === secondIdx ? { ...card, flipped: false } : card
            )
          );
        }
        setFlippedIndices([]);
        setIsProcessing(false);
      }, 1000);

      return () => clearTimeout(timer);
    }
  }, [flippedIndices, cards, isProcessing]);

  const startNewGame = () => {
    // Create pairs of cards
    const selectedEmojis = [...emojis].sort(() => Math.random() - 0.5).slice(0, 8);
    const emojiPairs = [...selectedEmojis, ...selectedEmojis];
    
    // Shuffle the cards
    const shuffledCards = emojiPairs
      .sort(() => Math.random() - 0.5)
      .map((emoji, index) => ({
        id: index,
        emoji,
        flipped: false,
        matched: false
      }));

    setCards(shuffledCards);
    setMoves(0);
    setFlippedIndices([]);
    setGameWon(false);
    setIsProcessing(false);
  };

  const handleCardClick = (index: number) => {
    if (isProcessing || cards[index].flipped || cards[index].matched || flippedIndices.length >= 2) {
      return;
    }

    // Flip the card
    setCards(prev => 
      prev.map((card, idx) => 
        idx === index ? { ...card, flipped: true } : card
      )
    );
    
    setFlippedIndices(prev => [...prev, index]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600 mb-2">
            Memory Card Game
          </h1>
          <p className="text-gray-600 text-lg">Match the emoji pairs!</p>
        </header>

        <div className="flex justify-between items-center mb-6 bg-white/80 backdrop-blur-md rounded-xl p-4 shadow-md">
          <div className="flex items-center gap-2">
            <span className="text-xl">💡 Moves:</span>
            <span className="text-2xl font-bold text-purple-700">{moves}</span>
          </div>
          <button
            onClick={startNewGame}
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            New Game
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {cards.map((card, index) => (
            <div
              key={card.id}
              onClick={() => handleCardClick(index)}
              className={`
                aspect-square rounded-2xl shadow-lg cursor-pointer
                transition-all duration-300 transform hover:scale-105
                ${card.flipped || card.matched ? 'bg-white' : 'bg-gradient-to-br from-purple-500 to-pink-500'}
                ${card.matched ? 'opacity-70' : ''}
                ${(card.flipped && !card.matched) || isProcessing ? 'pointer-events-none' : ''}
              `}
            >
              <div className="h-full w-full flex items-center justify-center">
                {card.flipped || card.matched ? (
                  <span className="text-4xl md:text-5xl">{card.emoji}</span>
                ) : (
                  <span className="text-4xl md:text-5xl text-white/30">?</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {gameWon && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl p-8 max-w-md mx-4 text-center shadow-2xl">
              <h2 className="text-3xl font-bold text-purple-700 mb-4">🎉 Congratulations! 🎉</h2>
              <p className="text-gray-600 text-lg mb-2">You matched all the pairs!</p>
              <p className="text-xl font-semibold text-pink-600 mb-6">Total Moves: {moves}</p>
              <button
                onClick={startNewGame}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Play Again
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
